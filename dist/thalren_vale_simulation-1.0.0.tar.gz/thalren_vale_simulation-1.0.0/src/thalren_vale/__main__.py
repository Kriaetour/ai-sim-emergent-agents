# (c) 2026 Gemini (KriaetvAspie)
# Licensed under the Polyform Noncommercial License 1.0.0
"""Entry point for: python -m thalren_vale"""

from .sim import run

if __name__ == "__main__":
    run()
